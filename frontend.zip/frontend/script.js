
function login() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  if (username === "admin" && password === "1234") {
    document.getElementById("login-screen").style.display = "none";
    document.getElementById("main-screen").style.display = "block";
  } else {
    alert("بيانات الدخول خاطئة");
  }
}

function uploadImage() {
  const input = document.getElementById("imageInput");
  const file = input.files[0];
  if (!file) {
    alert("يرجى اختيار صورة");
    return;
  }

  const formData = new FormData();
  formData.append("image", file);

  fetch("http://localhost:5000/predict", {
    method: "POST",
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    const result = document.getElementById("result");
    const preview = document.getElementById("preview");

    result.innerHTML = `الكائن: ${data.class_name} <br> الثقة: ${(data.confidence * 100).toFixed(2)}%`;
    preview.src = URL.createObjectURL(file);
  })
  .catch(err => {
    console.error(err);
    alert("حدث خطأ أثناء التنبؤ");
  });
}

navigator.mediaDevices.getUserMedia({ video: true })
  .then(stream => {
    document.getElementById("camera").srcObject = stream;
  })
  .catch(err => {
    console.error("فشل في الوصول إلى الكاميرا", err);
  });

function capture() {
  const video = document.getElementById("camera");
  const canvas = document.getElementById("canvas");
  const context = canvas.getContext("2d");

  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  context.drawImage(video, 0, 0, canvas.width, canvas.height);

  canvas.toBlob(blob => {
    const formData = new FormData();
    formData.append("image", blob, "camera.jpg");

    fetch("http://localhost:5000/predict", {
  method: "POST",
  body: formData
})
.then(res => {
  console.log("Raw response:", res); // اطبع كائن الاستجابة بالكامل
  if (!res.ok) { // التحقق من رموز الحالة غير الناجحة (مثل 400 أو 500)
      console.error("HTTP error! status:", res.status);
      return res.text().then(text => { throw new Error("HTTP error " + res.status + ": " + text) });
  }
  return res.text(); // استلم الاستجابة كنص بدلاً من JSON مباشرة
})
.then(text => {
  console.log("Response text:", text); // اطبع النص الخام للاستجابة
  try {
    const data = JSON.parse(text); // حاول تحليل النص على أنه JSON يدويًا
    console.log("Parsed JSON data:", data); // اطبع بيانات JSON بعد التحليل

    const result = document.getElementById("result");
    const preview = document.getElementById("preview");

    result.innerHTML = `الكائن: ${data.class_name} <br> الثقة: ${(data.confidence * 100).toFixed(2)}%`;
    // تأكد من أن هذا السطر موجود فقط في دالة uploadImage إذا كان capture لا يعرض الصورة
    if (preview && typeof URL.createObjectURL(file) !== 'undefined') {
         preview.src = URL.createObjectURL(file);
    }

  } catch (e) {
    console.error("Error parsing JSON or processing data:", e);
    throw new Error("Error processing server response: " + e.message);
  }
})
.catch(err => {
  console.error("Fetch error:", err);
  alert("حدث خطأ أثناء التنبؤ");
});
  }, "image/jpeg");
}
